package com.iheart.ssi.main;

public class StartMain {
	public static void main(String[] args) {
//		//
//		PropertyLoader loader = PropertyLoader.getInstance();
//		loader.setConfig(args[0], args[1], args[2]);
//		
//		SocketServer server = new SocketServer();
//		server.process();
	}
}
