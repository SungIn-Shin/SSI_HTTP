package com.iheart.ssi.logger;

public interface LogHandler {
	public void append(String logMsg);
}
